#include <iostream>
using namespace std;

    enum PartyType{
        None,
        Window,
        door,
        tire,
        rim,
        engine,
        radiator
    };
