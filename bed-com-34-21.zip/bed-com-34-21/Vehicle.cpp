#include <iostream>
using namespace std;
#include <string>

class Vehicle{
    class SpareParts{
        string* const static arr=[5];
        
    }


};